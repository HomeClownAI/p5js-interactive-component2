let revenueSlider, cogsSlider, operatingExpensesSlider;
let revenue, cogs, operatingExpenses, grossProfit, operatingProfit, netProfit, taxesInterest;

function setup() {
  createCanvas(800, 600);
  
  // Labels
  textSize(16);
  fill(0);
  
  // Revenue Slider
  createP('Revenue');
  revenueSlider = createSlider(0, 100000, 50000, 1000);
  
  // COGS Slider
  createP('Cost of Goods Sold (COGS)');
  cogsSlider = createSlider(0, 50000, 20000, 1000);
  
  // Operating Expenses Slider
  createP('Operating Expenses');
  operatingExpensesSlider = createSlider(0, 30000, 10000, 1000);
  
  // Taxes and Interest (fixed for this example)
  taxesInterest = 5000;
}

function draw() {
  background(255);
  
  // Get values from sliders
  revenue = revenueSlider.value();
  cogs = cogsSlider.value();
  operatingExpenses = operatingExpensesSlider.value();
  
  // Calculate profits
  grossProfit = revenue - cogs;
  operatingProfit = grossProfit - operatingExpenses;
  netProfit = operatingProfit - taxesInterest;
  
  // Display values
  text(`Revenue: $${revenue}`, 20, 50);
  text(`COGS: $${cogs}`, 20, 100);
  text(`Operating Expenses: $${operatingExpenses}`, 20, 150);
  text(`Taxes and Interest: $${taxesInterest}`, 20, 200);
  
  text(`Gross Profit: $${grossProfit}`, 20, 300);
  text(`Operating Profit: $${operatingProfit}`, 20, 350);
  text(`Net Profit: $${netProfit}`, 20, 400);
}
